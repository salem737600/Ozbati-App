package com.example.firebase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

import static com.example.firebase.R.id.bottomNavigationView;

public class Main5Activity extends MainActivity {
    TextView textaccount1;
    TextView textaccount2;
    TextView textaccount3;
    TextView textaccount4;
    TextView textaccount5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        textaccount1=(TextView)findViewById(R.id.textaccount1);
        textaccount2=(TextView)findViewById(R.id.textaccount2);
        textaccount3=(TextView)findViewById(R.id.textaccount3);
        textaccount4=(TextView)findViewById(R.id.textaccount4);
         textaccount5=(TextView)findViewById(R.id.textaccount5);


        BottomNavigationView bottomNavigationview= findViewById(bottomNavigationView);
        bottomNavigationview.setSelectedItemId(R.id.thirdFragment);

        bottomNavigationview.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch(menuItem.getItemId()){
                    case R.id.firstFragment:
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.secondFragment:
                        startActivity(new Intent(getApplicationContext(),Main4Activity.class));
                        overridePendingTransition(0,0);

                        return true;

                    case R.id.thirdFragment:
                          return true;
                }
                return false;
            }
        });


        String phonett = phonet.getText().toString().trim();

        tt=db.getstring(phonett);
        queryt(tt);


    }
    public void queryt(String tt1){

        Query query2= FirebaseDatabase.getInstance().getReference("me")
                .orderByChild("id").startAt(tt1).endAt(tt1+"\uf8ff");
        query2.addListenerForSingleValueEvent(valueEventListener1);
    }
    ValueEventListener valueEventListener1 = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            myarraylist2.clear();
            if (dataSnapshot.exists()) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    // member value = snapshot.getValue(member.class);
                    // String value=snapshot.child("name").getValue().toString();
                    //   String id=  snapshot.child("id").getValue().toString();
                    String total=snapshot.child("total").getValue().toString();
                    String total1=snapshot.child("total1").getValue().toString();
                    String total2=snapshot.child("total2").getValue().toString();
                    String total3=snapshot.child("total3").getValue().toString();
                    String total4=snapshot.child("total4").getValue().toString();
                    String name=snapshot.child("name").getValue().toString();
                    String name1=snapshot.child("name1").getValue().toString();
                    String name2=snapshot.child("name2").getValue().toString();
                    String name3=snapshot.child("name3").getValue().toString();
                    String name4=snapshot.child("name4").getValue().toString();
                    int number=Integer.parseInt(snapshot.child("number").getValue().toString());

                   if(number==5) {
                       textaccount1.setText("حساب" + "\t\t\t" + name + "\t\t\t" + total);
                       textaccount2.setText("حساب" + "\t\t\t" + name1 + "\t\t\t" + total1);
                       textaccount3.setText("حساب" + "\t\t\t" + name2 + "\t\t\t" + total2);
                       textaccount4.setText("حساب" + "\t\t\t" + name3 + "\t\t\t" + total3);
                       textaccount5.setText("حساب" + "\t\t\t" + name4 + "\t\t\t" + total4);
                   }else if(number==4){
                       textaccount1.setText("حساب" + "\t\t\t" + name + "\t\t\t" + total);
                       textaccount2.setText("حساب" + "\t\t\t" + name1 + "\t\t\t" + total1);
                       textaccount3.setText("حساب" + "\t\t\t" + name2 + "\t\t\t" + total2);
                       textaccount4.setText("حساب" + "\t\t\t" + name3 + "\t\t\t" + total3);
                   }
                   else if(number==3){
                       textaccount1.setText("حساب" + "\t\t\t" + name + "\t\t\t" + total);
                       textaccount2.setText("حساب" + "\t\t\t" + name1 + "\t\t\t" + total1);
                       textaccount3.setText("حساب" + "\t\t\t" + name2 + "\t\t\t" + total2);
                   }else if(number==2){
                       textaccount1.setText("حساب" + "\t\t\t" + name + "\t\t\t" + total);
                       textaccount2.setText("حساب" + "\t\t\t" + name1 + "\t\t\t" + total1);

                   }else if(number==1){
                       textaccount1.setText("حساب" + "\t\t\t" + name + "\t\t\t" + total);
                   }





                }



            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }

    };

}
