package com.example.firebase;

public class mem {
  private  String id;
  private String number;
  private  String  myprice;
  private  String myprice1;
  private String myprice2;
    private  String myprice3;
    private String myprice4;

    public mem() {
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getMyprice4() {
        return myprice4;
    }

    public void setMyprice4(String myprice4) {
        this.myprice4 = myprice4;
    }

    public String getMyprice3() {
        return myprice3;
    }

    public void setMyprice3(String myprice3) {
        this.myprice3 = myprice3;
    }

    public String getMyprice() {
        return myprice;
    }

    public void setMyprice(String myprice) {
        this.myprice = myprice;
    }

    public String getMyprice2() {
        return myprice2;
    }

    public void setMyprice2(String myprice2) {
        this.myprice2 = myprice2;
    }

    public String getMyprice1() {
        return myprice1;
    }

    public void setMyprice1(String myprice1) {
        this.myprice1 = myprice1;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }


}
