package com.example.firebase;


import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import static com.example.firebase.R.id.bottomNavigationView;

public class Main4Activity extends MainActivity {
    ArrayAdapter<String> arrayAdapteraccount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        Button account=(Button) findViewById(R.id.accounts);
        ListView listViewaccount=(ListView)findViewById(R.id.listviewaccount);





        account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Main4Activity.this,Main5Activity.class);
                startActivity(intent);
            }
        });

        arrayAdapteraccount = new ArrayAdapter<String>(Main4Activity.this, android.R.layout.simple_list_item_1, myarraylist2);
        listViewaccount.setAdapter(arrayAdapteraccount);

        String phonett = phonet.getText().toString().trim();

        tt=db.getstring(phonett);
        query2(tt);


    }
    public void query2(String tt1){

        Query query2=FirebaseDatabase.getInstance().getReference("memb")
                .orderByChild("id").startAt(tt1).endAt(tt1+"\uf8ff");
        query2.addListenerForSingleValueEvent(valueEventListener1);
    }
    ValueEventListener valueEventListener1 = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            myarraylist2.clear();
            if (dataSnapshot.exists()) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    // member value = snapshot.getValue(member.class);
                    // String value=snapshot.child("name").getValue().toString();
                    //   String id=  snapshot.child("id").getValue().toString();
                    String phone=snapshot.child("phone").getValue().toString();
                    String item=snapshot.child("item").getValue().toString();
                    String price=snapshot.child("price").getValue().toString();
                    myarraylist2.add(phone + "....." + price);


                }


                arrayAdapteraccount.notifyDataSetChanged();

            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }

    };

}